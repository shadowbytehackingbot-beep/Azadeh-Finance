#!/usr/bin/env bash
# آیکون و اسپلش تمام‌صفحه را روی پروژه اندروید اعمال می‌کند
set -euo pipefail
RES=android/app/src/main/res
rm -rf "$RES"/mipmap-* "$RES"/drawable-port-* "$RES"/drawable-land-* "$RES"/drawable/splash.png
cp -r android-res/* "$RES"/
echo "Icon + splash applied."
