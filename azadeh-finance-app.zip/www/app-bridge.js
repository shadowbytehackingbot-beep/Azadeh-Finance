/* پل ذخیره/اشتراک‌گذاری فایل برای نسخه اندروید (Capacitor)
   صفحه به‌صورت پیش‌فرض از window.claude.use('downloads') برای ذخیره فایل استفاده می‌کند؛
   این فایل همان را با Filesystem + Share اندروید پیاده می‌کند. */
(function () {
  var C = window.Capacitor;
  if (!C || !C.isNativePlatform || !C.isNativePlatform()) return;
  function toBase64(bytes) {
    var s = '', chunk = 0x8000;
    for (var i = 0; i < bytes.length; i += chunk) s += String.fromCharCode.apply(null, bytes.subarray(i, i + chunk));
    return btoa(s);
  }
  async function asBytes(data) {
    if (typeof data === 'string') return new TextEncoder().encode(data);
    if (data instanceof Blob) return new Uint8Array(await data.arrayBuffer());
    if (data instanceof ArrayBuffer) return new Uint8Array(data);
    if (ArrayBuffer.isView(data)) return new Uint8Array(data.buffer, data.byteOffset, data.byteLength);
    return new TextEncoder().encode(String(data));
  }
  window.claude = window.claude || {};
  var prev = window.claude.use;
  window.claude.use = async function (name) {
    if (name !== 'downloads') return prev ? prev.apply(this, arguments) : null;
    return {
      save: async function (opts) {
        try {
          var P = C.Plugins, bytes = await asBytes(opts.data);
          var r = await P.Filesystem.writeFile({ path: opts.filename, data: toBase64(bytes), directory: 'CACHE', recursive: true });
          await P.Share.share({ title: opts.filename, url: r.uri, dialogTitle: 'ذخیره / اشتراک‌گذاری فایل' });
        } catch (e) {
          if (e && /cancel/i.test(String(e.message || e))) { var d = new Error('declined'); d.code = 'declined'; throw d; }
          throw e;
        }
      }
    };
  };
})();
